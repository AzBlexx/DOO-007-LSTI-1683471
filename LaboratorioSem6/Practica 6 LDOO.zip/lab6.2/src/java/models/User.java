/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author AzBlexxADM
 */
public class User {
    private String username;
    private String password;
    private String nombre;
    private String apellidos;
    
    
   public User(String username,String password){
     this.username=username;
     this.password=password;
     this.nombre="Gilberto";
     this.apellidos="Contreras Silva";
     
    }
    
    
    public String getName(){
        return nombre;
    }
    public String getLastName(){
        return apellidos;
    }
    
    public String getFullName(){
         
        return getName() + " " + getLastName(); 
    }
    


    
    public String getUsername(){
    return username;
    }
    
}
