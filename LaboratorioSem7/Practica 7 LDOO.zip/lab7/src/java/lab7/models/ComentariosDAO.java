/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7.models;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javafx.beans.binding.Bindings.select;
import lab7.models.ComentariosPOJO;
/**
 *
 * @author Gilberto Alejandro Contreras Silva - 1683471
 */
public class ComentariosDAO {
    private Connection conexion;
    
    private void abrirConexion() throws SQLException{
        String dbURI= "jdbc:derby://localhost:1527/Comentarios";
        String username="fcfm";
        String password="lsti01";
        
        
        conexion = DriverManager.getConnection(dbURI, username, password);
        
    }
    
    private void cerrarConexion() throws SQLException{
        conexion.close();
    }
    
    public void insertar(ComentariosPOJO comentario) throws SQLException{
        try{
            abrirConexion();
            String insert="insert into COMENTARIOS values ('" + comentario.getNombre()+ "','"+comentario.getComentario()+"')";
            Statement stmt = conexion.createStatement();
            stmt.executeUpdate(insert);
            cerrarConexion();
         
        }catch(Exception hola){
        
        }
        
        
    }
    public List buscar(ComentariosPOJO comentario){
        ResultSet mensajes;
        List beans = new ArrayList();
        
        try{
            abrirConexion();
            String select =  "select * from COMENTARIOS where NOMBRE = '" + comentario.getNombre() + "' and COMENTARIO like '%" + comentario.getComentario() + "%'";
            Statement stmt = conexion.createStatement();
            mensajes = stmt.executeQuery(select);
            while(mensajes.next()){
                comentario= new ComentariosPOJO();
                comentario.setNombre(mensajes.getString("NOMBRE"));
                comentario.setComentario(mensajes.getString("COMENTARIO"));
                beans.add(comentario);
                
            }
            
            cerrarConexion();
            return beans;
        }catch (SQLException ex) {
            return null;
        }
        
        //return (ArrayList<ComentariosPOJO>) beans;
    }
    
    

}
