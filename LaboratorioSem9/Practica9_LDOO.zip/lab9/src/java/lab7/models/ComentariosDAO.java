/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7.models;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javafx.beans.binding.Bindings.select;
import lab7.models.ComentariosPOJO;
import lab7.models.Log;
/**
 *
 * @author Gilberto Alejandro Contreras Silva - 1683471
 */
public class ComentariosDAO {
    Log log = Log.getInstance("C:\\Users\\AzBlexxADM\\Documents\\NetBeansProjects\\lab9\\src\\text.txt");
    private Connection conexion;
    
    private void abrirConexion() throws SQLException{
        String dbURI= "jdbc:derby://localhost:1527/Comentarios";
        String username="fcfm";
        String password="lsti01";
        
        
        conexion = DriverManager.getConnection(dbURI, username, password);
        
    }
    
    private void cerrarConexion() throws SQLException{
        conexion.close();
    }
    
    public void insertar(ComentariosPOJO comentario){
        try{
            
            
            abrirConexion();
            String insert="insert into COMENTARIOS values ('" + comentario.getNombre()+ "','"+comentario.getComentario()+"')";
            Statement stmt = conexion.createStatement();
            stmt.executeUpdate(insert);
            cerrarConexion();
            log.write("Se insertó un registro en la base de daos");
        }catch(Exception ex){
            log.write("Ocurrio un error");
        }
        
        
    }
    public List buscar(ComentariosPOJO comentario){
        ResultSet mensajes;
        List beans = new ArrayList();
        
        try{
            abrirConexion();
            String select =  "select * from COMENTARIOS where NOMBRE = '" + comentario.getNombre() + "' and COMENTARIO like '%" + comentario.getComentario() + "%'";
            Statement stmt = conexion.createStatement();
            mensajes = stmt.executeQuery(select);
            while(mensajes.next()){
                comentario= new ComentariosPOJO();
                comentario.setNombre(mensajes.getString("NOMBRE"));
                comentario.setComentario(mensajes.getString("COMENTARIO"));
                beans.add(comentario);
                
            }
            
            cerrarConexion();
            log.write("Se ha buscado un registro");
            return beans;
            
        }catch (SQLException ex) {
            log.write("Ocurrio un error");
            return null;
        }
        
    }
    
    

}
